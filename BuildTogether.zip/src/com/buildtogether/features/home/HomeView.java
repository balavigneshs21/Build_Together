package com.buildtogether.features.home;

import com.buildtogether.dto.User;
import com.buildtogether.features.developer.DeveloperView;
import com.buildtogether.features.team.TeamView;
import com.buildtogether.features.project.ProjectView;
import com.buildtogether.features.discovery.ProjectSearchView;
import com.buildtogether.features.funding.FundingView;
import com.buildtogether.features.investment.InvestmentView;
import com.buildtogether.features.contact.ContactView;
import com.buildtogether.util.ConsoleInput;

import java.util.Scanner;

public class HomeView {

    private final HomeModel homeModel;
    private final User user;
    private final Scanner scanner;

    public HomeView(User user) {
        this.homeModel = new HomeModel(this);
        this.user = user;
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        homeModel.init(user);
    }

    void showUnauthorized() {
        System.out.println("Your account role is not set. Please contact support.");
    }

    // =========================================================================
    // DEVELOPER MENU
    // =========================================================================

    void showDeveloperMenu() {
        while (true) {
            System.out.println();
            System.out.println("=== Developer Home — " + user.getName() + " ===");
            System.out.println("1. My profile");
            System.out.println("2. Create team");
            System.out.println("3. Manage team members");
            System.out.println("4. Post project idea");
            System.out.println("5. Add tech stack to project");
            System.out.println("6. Update project status");
            System.out.println("7. Search investors");
            System.out.println("8. Apply for funding");
            System.out.println("9. Sign out");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    // view profile if exists, create if not
                    new DeveloperView(user).initViewOrCreate();
                    break;
                case "2":
                    new TeamView(user).init();
                    break;
                case "3":
                    new TeamView(user).initManageMembers();
                    break;
                case "4":
                    new ProjectView(user).init();
                    break;
                case "5":
                    new ProjectView(user).initAddTechStack();
                    break;
                case "6":
                    new ProjectView(user).initUpdateStatus();
                    break;
                case "7":
                    new ProjectSearchView(user).initSearchInvestors();
                    break;
                case "8":
                    new FundingView(user).init();
                    break;
                case "9":
                    System.out.println("You have been signed out. Goodbye, "
                            + user.getName() + "!");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // =========================================================================
    // INVESTOR MENU
    // =========================================================================

    void showInvestorMenu() {
        while (true) {
            System.out.println();
            System.out.println("=== Investor Home — " + user.getName() + " ===");
            System.out.println("1. My profile");
            System.out.println("2. View all projects");
            System.out.println("3. Filter projects");
            System.out.println("4. View team details");
            System.out.println("5. Contact team leader");
            System.out.println("6. Invest in project");
            System.out.println("7. Track my investments");
            System.out.println("8. Sign out");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    new InvestmentView(user).initProfile();
                    break;
                case "2":
                    new ProjectSearchView(user).initViewAllProjects();
                    break;
                case "3":
                    new ProjectSearchView(user).initFilterProjects();
                    break;
                case "4":
                    new ProjectSearchView(user).initViewTeamDetails();
                    break;
                case "5":
                    new ContactView(user).init();
                    break;
                case "6":
                    new InvestmentView(user).initInvest();
                    break;
                case "7":
                    new InvestmentView(user).initTrackInvestments();
                    break;
                case "8":
                    System.out.println("You have been signed out. Goodbye, "
                            + user.getName() + "!");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
