package com.buildtogether.features.funding;

import com.buildtogether.dto.Developer;
import com.buildtogether.dto.FundingApplication;
import com.buildtogether.dto.Investor;
import com.buildtogether.dto.Project;
import com.buildtogether.dto.Team;
import com.buildtogether.dto.User;
import com.buildtogether.repository.BuildTogetherDB;

import java.util.List;

class FundingModel {

    private final FundingView fundingView;

    FundingModel(FundingView fundingView) {
        this.fundingView = fundingView;
    }

    // =========================================================================
    // Load developer's projects + all investors
    // =========================================================================

    void loadMyProjectsAndInvestors(User user) {

        // Step 1 — check developer profile exists
        Developer developer = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (developer == null) {
            fundingView.showError(
                    "Please complete your developer profile first (option 1)");
            return;
        }

        // Step 2 — check team exists
        Team team = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(developer.getId());
        if (team == null) {
            fundingView.showError(
                    "Please create a team first (option 2)");
            return;
        }

        // Step 3 — get this team's projects
        List<Project> projects = BuildTogetherDB.getInstance()
                .getProjectsByTeamId(team.getId());

        // Step 4 — get all investors
        List<Investor> investors = BuildTogetherDB.getInstance().getAllInvestors();

        // Step 5 — pass both to View
        fundingView.showProjectsAndInvestors(projects, investors);
    }

    // =========================================================================
    // Apply for funding
    // =========================================================================

    void applyForFunding(User user, String projectIdInput,
                         String investorIdInput, String amountInput) {

        // Step 1 — parse project ID
        Long projectId;
        try {
            projectId = Long.parseLong(projectIdInput);
        } catch (NumberFormatException e) {
            fundingView.onApplicationFailed(
                    "Invalid project ID. Please enter a number.");
            return;
        }

        // Step 2 — parse investor ID
        Long investorId;
        try {
            investorId = Long.parseLong(investorIdInput);
        } catch (NumberFormatException e) {
            fundingView.onApplicationFailed(
                    "Invalid investor ID. Please enter a number.");
            return;
        }

        // Step 3 — parse and validate amount
        Double requestedAmount;
        try {
            requestedAmount = Double.parseDouble(amountInput);
            if (requestedAmount <= 0) {
                fundingView.onApplicationFailed(
                        "Requested amount must be greater than 0");
                return;
            }
        } catch (NumberFormatException e) {
            fundingView.onApplicationFailed(
                    "Invalid amount. Please enter a number.");
            return;
        }

        // Step 4 — check project exists
        Project project = BuildTogetherDB.getInstance().getProjectById(projectId);
        if (project == null) {
            fundingView.onApplicationFailed(
                    "No project found with ID: " + projectId);
            return;
        }

        // Step 5 — check project belongs to this developer's team
        Developer developer = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        Team team = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(developer.getId());
        if (team == null || !team.getId().equals(project.getTeamId())) {
            fundingView.onApplicationFailed(
                    "This project does not belong to your team");
            return;
        }

        // Step 6 — check investor exists
        Investor investor = BuildTogetherDB.getInstance()
                .getInvestorById(investorId);
        if (investor == null) {
            fundingView.onApplicationFailed(
                    "No investor found with ID: " + investorId);
            return;
        }

        // Step 7 — check no pending application already exists
        boolean alreadyApplied = BuildTogetherDB.getInstance()
                .hasPendingApplication(projectId, investorId);
        if (alreadyApplied) {
            fundingView.onApplicationFailed(
                    "You already have a pending application for this project "
                    + "with this investor");
            return;
        }

        // Step 8 — check requested amount does not exceed investor's funds
        if (requestedAmount > investor.getAvailableFunds()) {
            fundingView.onApplicationFailed(
                    "Requested amount exceeds investor's available funds ("
                    + investor.getAvailableFunds() + ")");
            return;
        }

        // Step 9 — build and save funding application
        FundingApplication application = new FundingApplication();
        application.setProjectId(projectId);
        application.setInvestorId(investorId);
        application.setRequestedAmount(requestedAmount);

        FundingApplication saved = BuildTogetherDB.getInstance()
                .addFundingApplication(application);

        if (saved != null) {
            fundingView.onApplicationSuccess(saved);
        } else {
            fundingView.onApplicationFailed(
                    "Something went wrong. Please try again.");
        }
    }
}