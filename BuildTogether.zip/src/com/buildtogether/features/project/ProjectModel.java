package com.buildtogether.features.project;

import com.buildtogether.dto.Developer;
import com.buildtogether.dto.Project;
import com.buildtogether.dto.Team;
import com.buildtogether.dto.TechStack;
import com.buildtogether.dto.User;
import com.buildtogether.repository.BuildTogetherDB;

import java.util.List;

class ProjectModel {

    private final ProjectView projectView;

    ProjectModel(ProjectView projectView) {
        this.projectView = projectView;
    }

    // =========================================================================
    // Create project
    // =========================================================================

    void createProject(User user, String title, String description,
                       String domain, String costInput, String timelineInput) {

        // Step 1 — validate title
        if (title == null || title.isEmpty()) {
            projectView.onProjectCreateFailed("Title cannot be empty");
            return;
        }

        // Step 2 — validate description
        if (description == null || description.isEmpty()) {
            projectView.onProjectCreateFailed("Description cannot be empty");
            return;
        }

        // Step 3 — validate domain
        if (domain == null || domain.isEmpty()) {
            projectView.onProjectCreateFailed("Domain cannot be empty");
            return;
        }

        // Step 4 — parse and validate cost
        Double estimatedCost;
        try {
            estimatedCost = Double.parseDouble(costInput);
            if (estimatedCost <= 0) {
                projectView.onProjectCreateFailed("Cost must be greater than 0");
                return;
            }
        } catch (NumberFormatException e) {
            projectView.onProjectCreateFailed("Invalid cost. Please enter a number.");
            return;
        }

        // Step 5 — parse and validate timeline
        Integer timelineDays;
        try {
            timelineDays = Integer.parseInt(timelineInput);
            if (timelineDays <= 0) {
                projectView.onProjectCreateFailed("Timeline must be greater than 0 days");
                return;
            }
        } catch (NumberFormatException e) {
            projectView.onProjectCreateFailed("Invalid timeline. Please enter a number.");
            return;
        }

        // Step 6 — check developer profile exists
        Developer developer = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (developer == null) {
            projectView.onProjectCreateFailed(
                    "Please complete your developer profile first (option 1)");
            return;
        }

        // Step 7 — check team exists
        Team team = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(developer.getId());
        if (team == null) {
            projectView.onProjectCreateFailed(
                    "Please create a team first (option 2)");
            return;
        }

        // Step 8 — build and save project
        Project project = new Project();
        project.setTitle(title);
        project.setDescription(description);
        project.setTeamId(team.getId());
        project.setDomain(domain);
        project.setEstimatedCost(estimatedCost);
        project.setTimelineDays(timelineDays);

        Project saved = BuildTogetherDB.getInstance().addProject(project);
        if (saved != null) {
            projectView.onProjectCreated(saved);
        } else {
            projectView.onProjectCreateFailed("Something went wrong. Please try again.");
        }
    }

    // =========================================================================
    // Load my projects — for tech stack screen
    // =========================================================================

    void loadMyProjects(User user) {
        Developer developer = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (developer == null) {
            projectView.showError(
                    "Please complete your developer profile first (option 1)");
            return;
        }

        Team team = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(developer.getId());
        if (team == null) {
            projectView.showError(
                    "Please create a team first (option 2)");
            return;
        }

        List<Project> projects = BuildTogetherDB.getInstance()
                .getProjectsByTeamId(team.getId());
        projectView.showMyProjectsForTechStack(projects);
    }

    // =========================================================================
    // Load my projects — for status update screen
    // =========================================================================

    void loadMyProjectsForStatus(User user) {
        Developer developer = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (developer == null) {
            projectView.showError(
                    "Please complete your developer profile first (option 1)");
            return;
        }

        Team team = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(developer.getId());
        if (team == null) {
            projectView.showError(
                    "Please create a team first (option 2)");
            return;
        }

        List<Project> projects = BuildTogetherDB.getInstance()
                .getProjectsByTeamId(team.getId());
        projectView.showMyProjectsForStatus(projects);
    }

    // =========================================================================
    // Add tech stack
    // =========================================================================

    void addTechStack(User user, String projectIdInput, String technology) {

        // Step 1 — validate technology name
        if (technology == null || technology.isEmpty()) {
            projectView.onTechStackFailed("Technology name cannot be empty");
            return;
        }

        // Step 2 — parse project ID
        Long projectId;
        try {
            projectId = Long.parseLong(projectIdInput);
        } catch (NumberFormatException e) {
            projectView.onTechStackFailed("Invalid project ID. Please enter a number.");
            return;
        }

        // Step 3 — check project exists
        Project project = BuildTogetherDB.getInstance().getProjectById(projectId);
        if (project == null) {
            projectView.onTechStackFailed("No project found with ID: " + projectId);
            return;
        }

        // Step 4 — check this project belongs to user's team
        Developer developer = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        Team team = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(developer.getId());
        if (team == null || !team.getId().equals(project.getTeamId())) {
            projectView.onTechStackFailed("This project does not belong to your team");
            return;
        }

        // Step 5 — build and save tech stack
        TechStack techStack = new TechStack();
        techStack.setProjectId(projectId);
        techStack.setTechnology(technology);

        TechStack saved = BuildTogetherDB.getInstance().addTechStack(techStack);
        if (saved != null) {
            projectView.onTechStackAdded(saved);
        } else {
            projectView.onTechStackFailed("Something went wrong. Please try again.");
        }
    }

    // =========================================================================
    // Update project status
    // =========================================================================

    void updateProjectStatus(User user, String projectIdInput, String statusChoice) {

        // Step 1 — parse project ID
        Long projectId;
        try {
            projectId = Long.parseLong(projectIdInput);
        } catch (NumberFormatException e) {
            projectView.onStatusUpdateFailed("Invalid project ID. Please enter a number.");
            return;
        }

        // Step 2 — check project exists
        Project project = BuildTogetherDB.getInstance().getProjectById(projectId);
        if (project == null) {
            projectView.onStatusUpdateFailed("No project found with ID: " + projectId);
            return;
        }

        // Step 3 — check this project belongs to user's team
        Developer developer = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        Team team = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(developer.getId());
        if (team == null || !team.getId().equals(project.getTeamId())) {
            projectView.onStatusUpdateFailed(
                    "This project does not belong to your team");
            return;
        }

        // Step 4 — map choice to status enum
        Project.ProjectStatus newStatus;
        switch (statusChoice) {
            case "1":
                newStatus = Project.ProjectStatus.IDEA;
                break;
            case "2":
                newStatus = Project.ProjectStatus.IN_PROGRESS;
                break;
            case "3":
                newStatus = Project.ProjectStatus.COMPLETED;
                break;
            default:
                projectView.onStatusUpdateFailed(
                        "Invalid choice. Please choose 1, 2 or 3.");
                return;
        }

        // Step 5 — update and save
        project.setStatus(newStatus);
        Project updated = BuildTogetherDB.getInstance().updateProject(project);
        if (updated != null) {
            projectView.onStatusUpdated(updated);
        } else {
            projectView.onStatusUpdateFailed("Something went wrong. Please try again.");
        }
    }
}