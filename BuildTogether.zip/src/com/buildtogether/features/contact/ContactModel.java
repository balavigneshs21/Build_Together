package com.buildtogether.features.contact;

import com.buildtogether.dto.ContactRequest;
import com.buildtogether.dto.Investor;
import com.buildtogether.dto.Team;
import com.buildtogether.dto.User;
import com.buildtogether.repository.BuildTogetherDB;

import java.util.List;

class ContactModel {

    private final ContactView contactView;

    ContactModel(ContactView contactView) {
        this.contactView = contactView;
    }

    // =========================================================================
    // Load all teams
    // =========================================================================

    void loadAllTeams(User user) {

        // Step 1 — check investor profile exists
        Investor investor = BuildTogetherDB.getInstance()
                .getInvestorByUserId(user.getId());
        if (investor == null) {
            contactView.showError(
                    "Please complete your investor profile first (option 1)");
            return;
        }

        // Step 2 — get all teams
        List<Team> teams = BuildTogetherDB.getInstance().getAllTeams();
        if (teams.isEmpty()) {
            contactView.showError("No teams available to contact.");
            return;
        }

        contactView.showAllTeams(teams);
    }

    // =========================================================================
    // Send contact request
    // =========================================================================

    void sendContactRequest(User user, String leaderIdInput, String message) {

        // Step 1 — validate message
        if (message == null || message.isEmpty()) {
            contactView.onRequestFailed("Message cannot be empty");
            return;
        }

        // Step 2 — parse team leader ID
        Long teamLeaderId;
        try {
            teamLeaderId = Long.parseLong(leaderIdInput);
        } catch (NumberFormatException e) {
            contactView.onRequestFailed(
                    "Invalid leader ID. Please enter a number.");
            return;
        }

        // Step 3 — get investor profile
        Investor investor = BuildTogetherDB.getInstance()
                .getInvestorByUserId(user.getId());
        if (investor == null) {
            contactView.onRequestFailed("Investor profile not found");
            return;
        }

        // Step 4 — check team leader exists
        // team leader ID is a developer ID — check developer exists
        if (BuildTogetherDB.getInstance().getDeveloperById(teamLeaderId) == null) {
            contactView.onRequestFailed(
                    "No team leader found with ID: " + teamLeaderId);
            return;
        }

        // Step 5 — check not already contacted
        boolean alreadyContacted = BuildTogetherDB.getInstance()
                .hasAlreadyContacted(investor.getId(), teamLeaderId);
        if (alreadyContacted) {
            contactView.onRequestFailed(
                    "You already have a pending contact request to this team leader");
            return;
        }

        // Step 6 — build and save contact request
        ContactRequest request = new ContactRequest();
        request.setInvestorId(investor.getId());
        request.setTeamLeaderId(teamLeaderId);
        request.setMessage(message);

        ContactRequest saved = BuildTogetherDB.getInstance()
                .addContactRequest(request);

        if (saved != null) {
            contactView.onRequestSent(saved);
        } else {
            contactView.onRequestFailed(
                    "Something went wrong. Please try again.");
        }
    }

    // =========================================================================
    // Load sent contact requests
    // =========================================================================

    void loadSentRequests(User user) {

        // Step 1 — check investor profile exists
        Investor investor = BuildTogetherDB.getInstance()
                .getInvestorByUserId(user.getId());
        if (investor == null) {
            contactView.showError(
                    "Please complete your investor profile first (option 1)");
            return;
        }

        // Step 2 — get all requests sent by this investor
        List<ContactRequest> requests = BuildTogetherDB.getInstance()
                .getContactRequestsByInvestorId(investor.getId());

        contactView.showSentRequests(requests);
    }
}