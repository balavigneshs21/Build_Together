package com.buildtogether.features.contact;

import com.buildtogether.dto.ContactRequest;
import com.buildtogether.dto.Team;
import com.buildtogether.dto.User;
import com.buildtogether.util.ConsoleInput;

import java.util.List;
import java.util.Scanner;

public class ContactView {

    private final ContactModel contactModel;
    private final User user;
    private final Scanner scanner;

    public ContactView(User user) {
        this.user = user;
        this.contactModel = new ContactModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    // ── called from HomeView Investor case "5" ─────────────────────────────
    public void init() {
        System.out.println();
        System.out.println("=== Contact Team Leader ===");
        System.out.println("1. Send contact request");
        System.out.println("2. View my sent requests");
        System.out.print("Choose an option: ");
        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                contactModel.loadAllTeams(user);
                break;
            case "2":
                contactModel.loadSentRequests(user);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    // =========================================================================
    // Callbacks — ContactModel calls these back
    // =========================================================================

    void showAllTeams(List<Team> teams) {
        if (teams.isEmpty()) {
            System.out.println("No teams found.");
            return;
        }

        System.out.println();
        System.out.println("Available Teams:");
        System.out.println("──────────────────────────────────────────");
        for (Team team : teams) {
            System.out.println("Team ID      : " + team.getId());
            System.out.println("Team Name    : " + team.getTeamName());
            System.out.println("Leader ID    : " + team.getTeamLeaderId());
            System.out.println("──────────────────────────────────────────");
        }

        System.out.print("Enter Team Leader ID to contact (or 0 to cancel): ");
        String leaderIdInput = scanner.nextLine().trim();
        if (leaderIdInput.equals("0")) return;

        System.out.print("Enter your message: ");
        String message = scanner.nextLine().trim();

        contactModel.sendContactRequest(user, leaderIdInput, message);
    }

    void showSentRequests(List<ContactRequest> requests) {
        if (requests.isEmpty()) {
            System.out.println("You have not sent any contact requests yet.");
            return;
        }

        System.out.println();
        System.out.println("Your Sent Contact Requests:");
        System.out.println("──────────────────────────────────────────");
        for (ContactRequest request : requests) {
            System.out.println("Request ID    : " + request.getId());
            System.out.println("Team Leader ID: " + request.getTeamLeaderId());
            System.out.println("Message       : " + request.getMessage());
            System.out.println("Status        : " + request.getStatus());
            System.out.println("──────────────────────────────────────────");
        }
    }

    void onRequestSent(ContactRequest request) {
        System.out.println();
        System.out.println("Contact request sent successfully!");
        System.out.println("Request ID    : " + request.getId());
        System.out.println("Team Leader ID: " + request.getTeamLeaderId());
        System.out.println("Message       : " + request.getMessage());
        System.out.println("Status        : " + request.getStatus());
    }

    void onRequestFailed(String message) {
        System.out.println("Contact request failed: " + message);
    }

    void showError(String message) {
        System.out.println("Error: " + message);
    }
}