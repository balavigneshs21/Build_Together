package com.buildtogether.features.investment;

import com.buildtogether.dto.FundingApplication;
import com.buildtogether.dto.Investment;
import com.buildtogether.dto.Investor;
import com.buildtogether.dto.Project;
import com.buildtogether.dto.User;
import com.buildtogether.repository.BuildTogetherDB;

import java.util.ArrayList;
import java.util.List;

class InvestmentModel {

    private final InvestmentView investmentView;

    InvestmentModel(InvestmentView investmentView) {
        this.investmentView = investmentView;
    }

    // =========================================================================
    // Load investor profile
    // =========================================================================

    void loadProfile(User user) {
        Investor existing = BuildTogetherDB.getInstance()
                .getInvestorByUserId(user.getId());
        if (existing != null) {
            // profile already exists — just show it
            investmentView.showExistingProfile(existing);
        } else {
            // no profile yet — ask user to fill it
            investmentView.showProfileSetup();
        }
    }

    // =========================================================================
    // Create investor profile
    // =========================================================================

    void createProfile(User user, String companyName, String fundsInput) {

        // Step 1 — validate company name
        if (companyName == null || companyName.isEmpty()) {
            investmentView.onProfileFailed("Company name cannot be empty");
            return;
        }

        // Step 2 — parse and validate funds
        Double availableFunds;
        try {
            availableFunds = Double.parseDouble(fundsInput);
            if (availableFunds <= 0) {
                investmentView.onProfileFailed(
                        "Available funds must be greater than 0");
                return;
            }
        } catch (NumberFormatException e) {
            investmentView.onProfileFailed(
                    "Invalid funds amount. Please enter a number.");
            return;
        }

        // Step 3 — check profile does not already exist
        Investor existing = BuildTogetherDB.getInstance()
                .getInvestorByUserId(user.getId());
        if (existing != null) {
            investmentView.onProfileFailed(
                    "An investor profile already exists for this account");
            return;
        }

        // Step 4 — build and save investor profile
        Investor investor = new Investor();
        investor.setUserId(user.getId());
        investor.setCompanyName(companyName);
        investor.setAvailableFunds(availableFunds);

        Investor saved = BuildTogetherDB.getInstance().addInvestor(investor);
        if (saved != null) {
            investmentView.onProfileCreated(saved);
        } else {
            investmentView.onProfileFailed(
                    "Something went wrong. Please try again.");
        }
    }

    // =========================================================================
    // Load pending funding applications for this investor
    // =========================================================================

    void loadPendingApplications(User user) {

        // Step 1 — check investor profile exists
        Investor investor = BuildTogetherDB.getInstance()
                .getInvestorByUserId(user.getId());
        if (investor == null) {
            investmentView.showError(
                    "Please complete your investor profile first (option 1)");
            return;
        }

        // Step 2 — get all pending applications for this investor
        List<FundingApplication> allApplications = BuildTogetherDB.getInstance()
                .getFundingApplicationsByInvestorId(investor.getId());

        // Step 3 — filter only PENDING ones
        List<FundingApplication> pending = new ArrayList<>();
        for (FundingApplication app : allApplications) {
            if (app.getStatus() == FundingApplication.ApplicationStatus.PENDING) {
                pending.add(app);
            }
        }

        // Step 4 — get all projects to show project titles
        List<Project> projects = BuildTogetherDB.getInstance().getAllProjects();

        investmentView.showPendingApplications(pending, projects);
    }

    // =========================================================================
    // Confirm investment
    // =========================================================================

    void confirmInvestment(User user, String appIdInput) {

        // Step 1 — parse application ID
        Long appId;
        try {
            appId = Long.parseLong(appIdInput);
        } catch (NumberFormatException e) {
            investmentView.onInvestmentFailed(
                    "Invalid application ID. Please enter a number.");
            return;
        }

        // Step 2 — get investor profile
        Investor investor = BuildTogetherDB.getInstance()
                .getInvestorByUserId(user.getId());
        if (investor == null) {
            investmentView.onInvestmentFailed(
                    "Investor profile not found");
            return;
        }

        // Step 3 — find the funding application
        List<FundingApplication> applications = BuildTogetherDB.getInstance()
                .getFundingApplicationsByInvestorId(investor.getId());

        FundingApplication targetApp = null;
        for (FundingApplication app : applications) {
            if (app.getId().equals(appId)) {
                targetApp = app;
                break;
            }
        }

        if (targetApp == null) {
            investmentView.onInvestmentFailed(
                    "No application found with ID: " + appId);
            return;
        }

        // Step 4 — check application is still PENDING
        if (targetApp.getStatus() != FundingApplication.ApplicationStatus.PENDING) {
            investmentView.onInvestmentFailed(
                    "This application is already " + targetApp.getStatus());
            return;
        }

        // Step 5 — check investor has enough funds
        if (targetApp.getRequestedAmount() > investor.getAvailableFunds()) {
            investmentView.onInvestmentFailed(
                    "Insufficient funds. Your available funds: "
                    + investor.getAvailableFunds());
            return;
        }

        // Step 6 — approve the funding application
        targetApp.setStatus(FundingApplication.ApplicationStatus.APPROVED);
        BuildTogetherDB.getInstance().updateFundingApplication(targetApp);

        // Step 7 — deduct amount from investor's available funds
        investor.setAvailableFunds(
                investor.getAvailableFunds() - targetApp.getRequestedAmount());

        // Step 8 — save the investment record
        Investment investment = new Investment();
        investment.setInvestorId(investor.getId());
        investment.setProjectId(targetApp.getProjectId());
        investment.setAmount(targetApp.getRequestedAmount());

        Investment saved = BuildTogetherDB.getInstance().addInvestment(investment);
        if (saved != null) {
            investmentView.onInvestmentSuccess(saved);
        } else {
            investmentView.onInvestmentFailed(
                    "Something went wrong. Please try again.");
        }
    }

    // =========================================================================
    // Load all investments made by this investor
    // =========================================================================

    void loadMyInvestments(User user) {

        // Step 1 — check investor profile exists
        Investor investor = BuildTogetherDB.getInstance()
                .getInvestorByUserId(user.getId());
        if (investor == null) {
            investmentView.showError(
                    "Please complete your investor profile first (option 1)");
            return;
        }

        // Step 2 — get all investments by this investor
        List<Investment> investments = BuildTogetherDB.getInstance()
                .getInvestmentsByInvestorId(investor.getId());

        // Step 3 — get all projects to show project titles and status
        List<Project> projects = BuildTogetherDB.getInstance().getAllProjects();

        investmentView.showMyInvestments(investments, projects);
    }
}