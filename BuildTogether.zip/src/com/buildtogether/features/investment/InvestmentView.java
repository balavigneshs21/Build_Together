package com.buildtogether.features.investment;

import com.buildtogether.dto.FundingApplication;
import com.buildtogether.dto.Investment;
import com.buildtogether.dto.Investor;
import com.buildtogether.dto.Project;
import com.buildtogether.dto.User;
import com.buildtogether.util.ConsoleInput;

import java.util.List;
import java.util.Scanner;

public class InvestmentView {

    private final InvestmentModel investmentModel;
    private final User user;
    private final Scanner scanner;

    public InvestmentView(User user) {
        this.user = user;
        this.investmentModel = new InvestmentModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    // ── called from HomeView Investor case "1" ─────────────────────────────
    public void initProfile() {
        System.out.println();
        System.out.println("=== Investor Profile Setup ===");
        investmentModel.loadProfile(user);
    }

    // ── called from HomeView Investor case "6" ─────────────────────────────
    public void initInvest() {
        System.out.println();
        System.out.println("=== Invest in a Project ===");
        investmentModel.loadPendingApplications(user);
    }

    // ── called from HomeView Investor case "7" ─────────────────────────────
    public void initTrackInvestments() {
        System.out.println();
        System.out.println("=== My Investments ===");
        investmentModel.loadMyInvestments(user);
    }

    // =========================================================================
    // Callbacks — InvestmentModel calls these back
    // =========================================================================

    // ── Profile callbacks ──────────────────────────────────────────────────

    void showProfileSetup() {
        System.out.print("Enter your company name: ");
        String companyName = scanner.nextLine().trim();

        System.out.print("Enter your available funds: ");
        String fundsInput = scanner.nextLine().trim();

        investmentModel.createProfile(user, companyName, fundsInput);
    }

    void showExistingProfile(Investor investor) {
        System.out.println();
        System.out.println("=== Your Investor Profile ===");
        System.out.println("Company        : " + investor.getCompanyName());
        System.out.println("Available Funds: " + investor.getAvailableFunds());
    }

    void onProfileCreated(Investor investor) {
        System.out.println();
        System.out.println("Investor profile created successfully!");
        System.out.println("Company        : " + investor.getCompanyName());
        System.out.println("Available Funds: " + investor.getAvailableFunds());
    }

    void onProfileFailed(String message) {
        System.out.println("Profile creation failed: " + message);
    }

    // ── Invest callbacks ───────────────────────────────────────────────────

    void showPendingApplications(List<FundingApplication> applications,
                                  List<Project> projects) {
        if (applications.isEmpty()) {
            System.out.println("No pending funding applications for you.");
            return;
        }

        System.out.println();
        System.out.println("Pending Funding Applications:");
        System.out.println("──────────────────────────────────────────");
        for (FundingApplication app : applications) {
            // find matching project title
            String projectTitle = "Unknown";
            for (Project project : projects) {
                if (project.getId().equals(app.getProjectId())) {
                    projectTitle = project.getTitle();
                    break;
                }
            }
            System.out.println("Application ID  : " + app.getId());
            System.out.println("Project         : " + projectTitle);
            System.out.println("Requested Amount: " + app.getRequestedAmount());
            System.out.println("Status          : " + app.getStatus());
            System.out.println("──────────────────────────────────────────");
        }

        System.out.print("Enter Application ID to invest (or 0 to cancel): ");
        String appIdInput = scanner.nextLine().trim();
        if (appIdInput.equals("0")) return;

        investmentModel.confirmInvestment(user, appIdInput);
    }

    void onInvestmentSuccess(Investment investment) {
        System.out.println();
        System.out.println("Investment confirmed successfully!");
        System.out.println("Investment ID : " + investment.getId());
        System.out.println("Project ID    : " + investment.getProjectId());
        System.out.println("Amount        : " + investment.getAmount());
    }

    void onInvestmentFailed(String message) {
        System.out.println("Investment failed: " + message);
    }

    // ── Track investments callbacks ────────────────────────────────────────

    void showMyInvestments(List<Investment> investments, List<Project> projects) {
        if (investments.isEmpty()) {
            System.out.println("You have not made any investments yet.");
            return;
        }

        System.out.println();
        System.out.println("Your Investments:");
        System.out.println("──────────────────────────────────────────");
        for (Investment investment : investments) {
            String projectTitle = "Unknown";
            String projectStatus = "Unknown";
            for (Project project : projects) {
                if (project.getId().equals(investment.getProjectId())) {
                    projectTitle = project.getTitle();
                    projectStatus = project.getStatus().toString();
                    break;
                }
            }
            System.out.println("Investment ID  : " + investment.getId());
            System.out.println("Project        : " + projectTitle);
            System.out.println("Amount Invested: " + investment.getAmount());
            System.out.println("Project Status : " + projectStatus);
            System.out.println("──────────────────────────────────────────");
        }
    }

    void showError(String message) {
        System.out.println("Error: " + message);
    }
}