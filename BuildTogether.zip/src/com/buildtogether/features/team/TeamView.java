package com.buildtogether.features.team;

import com.buildtogether.dto.Developer;
import com.buildtogether.dto.Team;
import com.buildtogether.dto.TeamMember;
import com.buildtogether.dto.User;
import com.buildtogether.util.ConsoleInput;

import java.util.List;
import java.util.Scanner;

public class TeamView {

    private final TeamModel teamModel;
    private final User user;
    private final Scanner scanner;

    public TeamView(User user) {
        this.user = user;
        this.teamModel = new TeamModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    // ── called from HomeView case "2" ──────────────────────────────────────
    public void init() {
        System.out.println();
        System.out.println("=== Create Team ===");

        System.out.print("Enter team name: ");
        String teamName = scanner.nextLine().trim();

        teamModel.createTeam(user, teamName);
    }

    // ── called from HomeView case "3" ──────────────────────────────────────
    public void initManageMembers() {
        System.out.println();
        System.out.println("=== Manage Team Members ===");
        System.out.println("1. Add a member");
        System.out.println("2. Remove a member");
        System.out.println("3. View current members");
        System.out.print("Choose an option: ");
        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                promptAddMember();
                break;
            case "2":
                promptRemoveMember();
                break;
            case "3":
                teamModel.loadMembers(user);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private void promptAddMember() {
        System.out.println();
        System.out.println("=== Add Member ===");
        teamModel.loadAllDevelopers(user);
    }

    private void promptRemoveMember() {
        System.out.println();
        System.out.println("=== Remove Member ===");
        teamModel.loadMembers(user);
    }

    // ── called back from TeamModel ─────────────────────────────────────────

    void onTeamCreated(Team team) {
        System.out.println();
        System.out.println("Team created successfully!");
        System.out.println("Team Name : " + team.getTeamName());
        System.out.println("Team ID   : " + team.getId());
        System.out.println("You are the team leader.");
    }

    void onTeamCreateFailed(String message) {
        System.out.println("Team creation failed: " + message);
    }

    void showAllDevelopers(List<Developer> developers, long myDeveloperId) {
        if (developers.isEmpty()) {
            System.out.println("No other developers found to add.");
            return;
        }
        System.out.println();
        System.out.println("Available Developers:");
        System.out.println("──────────────────────────────────");
        for (Developer dev : developers) {
            if (dev.getId() == myDeveloperId) continue;
            System.out.println("ID: " + dev.getId()
                    + " | Skills: " + dev.getSkills()
                    + " | Level: " + dev.getExperienceLevel());
        }
        System.out.println("──────────────────────────────────");
        System.out.print("Enter Developer ID to add (or 0 to cancel): ");
        String input = scanner.nextLine().trim();
        if (input.equals("0")) return;
        teamModel.addMember(user, input);
    }

    void showMembers(List<TeamMember> members) {
        if (members.isEmpty()) {
            System.out.println("No members in your team yet.");
            return;
        }
        System.out.println();
        System.out.println("Current Team Members:");
        System.out.println("──────────────────────────────────");
        for (TeamMember member : members) {
            System.out.println("Developer ID: " + member.getDeveloperId());
        }
        System.out.println("──────────────────────────────────");
        System.out.print("Enter Developer ID to remove (or 0 to cancel): ");
        String input = scanner.nextLine().trim();
        if (input.equals("0")) return;
        teamModel.removeMember(user, input);
    }

    void onMemberAdded(String developerName) {
        System.out.println("Member added successfully: " + developerName);
    }

    void onMemberAddFailed(String message) {
        System.out.println("Failed to add member: " + message);
    }

    void onMemberRemoved() {
        System.out.println("Member removed successfully.");
    }

    void onMemberRemoveFailed(String message) {
        System.out.println("Failed to remove member: " + message);
    }

    void showError(String message) {
        System.out.println("Error: " + message);
    }
}