package com.buildtogether.features.team;

import com.buildtogether.dto.Developer;
import com.buildtogether.dto.Team;
import com.buildtogether.dto.TeamMember;
import com.buildtogether.dto.User;
import com.buildtogether.repository.BuildTogetherDB;

import java.util.List;

class TeamModel {

    private final TeamView teamView;

    TeamModel(TeamView teamView) {
        this.teamView = teamView;
    }

    // ── Create team ────────────────────────────────────────────────────────

    void createTeam(User user, String teamName) {

        // Step 1 — validate team name
        if (teamName == null || teamName.isEmpty()) {
            teamView.onTeamCreateFailed("Team name cannot be empty");
            return;
        }

        // Step 2 — get the developer profile of this user
        Developer developer = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (developer == null) {
            teamView.onTeamCreateFailed(
                    "Please complete your developer profile first (option 1)");
            return;
        }

        // Step 3 — check if this developer already leads a team
        Team existing = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(developer.getId());
        if (existing != null) {
            teamView.onTeamCreateFailed(
                    "You already have a team: " + existing.getTeamName());
            return;
        }

        // Step 4 — build Team object and save
        Team team = new Team();
        team.setTeamName(teamName);
        team.setTeamLeaderId(developer.getId());

        Team saved = BuildTogetherDB.getInstance().addTeam(team);
        if (saved == null) {
            teamView.onTeamCreateFailed("Something went wrong. Please try again.");
            return;
        }

        // Step 5 — add the leader as first team member automatically
        TeamMember leaderMember = new TeamMember();
        leaderMember.setTeamId(saved.getId());
        leaderMember.setDeveloperId(developer.getId());
        BuildTogetherDB.getInstance().addTeamMember(leaderMember);

        teamView.onTeamCreated(saved);
    }

    // ── Load all developers (for add member screen) ────────────────────────

    void loadAllDevelopers(User user) {
        Developer myDeveloper = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (myDeveloper == null) {
            teamView.showError(
                    "Please complete your developer profile first (option 1)");
            return;
        }

        List<Developer> all = BuildTogetherDB.getInstance().getAllDevelopers();
        teamView.showAllDevelopers(all, myDeveloper.getId());
    }

    // ── Add member ─────────────────────────────────────────────────────────

    void addMember(User user, String developerIdInput) {

        // Step 1 — parse the developer ID input
        Long developerIdToAdd;
        try {
            developerIdToAdd = Long.parseLong(developerIdInput);
        } catch (NumberFormatException e) {
            teamView.onMemberAddFailed("Invalid ID. Please enter a number.");
            return;
        }

        // Step 2 — get this user's developer profile
        Developer myDeveloper = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (myDeveloper == null) {
            teamView.onMemberAddFailed(
                    "Please complete your developer profile first");
            return;
        }

        // Step 3 — get this user's team
        Team myTeam = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(myDeveloper.getId());
        if (myTeam == null) {
            teamView.onMemberAddFailed(
                    "You don't have a team yet. Create a team first (option 2)");
            return;
        }

        // Step 4 — check max 5 members limit
        int currentCount = BuildTogetherDB.getInstance()
                .getTeamMemberCount(myTeam.getId());
        if (currentCount >= 5) {
            teamView.onMemberAddFailed(
                    "Team is full. Maximum 5 members allowed.");
            return;
        }

        // Step 5 — check if developer exists
        Developer developerToAdd = BuildTogetherDB.getInstance()
                .getDeveloperById(developerIdToAdd);
        if (developerToAdd == null) {
            teamView.onMemberAddFailed(
                    "No developer found with ID: " + developerIdToAdd);
            return;
        }

        // Step 6 — check if already in team
        boolean alreadyIn = BuildTogetherDB.getInstance()
                .isAlreadyInTeam(myTeam.getId(), developerIdToAdd);
        if (alreadyIn) {
            teamView.onMemberAddFailed(
                    "This developer is already in your team");
            return;
        }

        // Step 7 — add the member
        TeamMember member = new TeamMember();
        member.setTeamId(myTeam.getId());
        member.setDeveloperId(developerIdToAdd);
        BuildTogetherDB.getInstance().addTeamMember(member);

        // Step 8 — get the developer's user name for confirmation message
        User memberUser = BuildTogetherDB.getInstance()
                .getUserById(developerToAdd.getUserId());
        String memberName = (memberUser != null) ? memberUser.getName() : "Developer";

        teamView.onMemberAdded(memberName);
    }

    // ── Load members (for view and remove screen) ──────────────────────────

    void loadMembers(User user) {
        Developer myDeveloper = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (myDeveloper == null) {
            teamView.showError(
                    "Please complete your developer profile first (option 1)");
            return;
        }

        Team myTeam = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(myDeveloper.getId());
        if (myTeam == null) {
            teamView.showError(
                    "You don't have a team yet. Create a team first (option 2)");
            return;
        }

        List<TeamMember> members = BuildTogetherDB.getInstance()
                .getMembersOfTeam(myTeam.getId());
        teamView.showMembers(members);
    }

    // ── Remove member ──────────────────────────────────────────────────────

    void removeMember(User user, String developerIdInput) {

        // Step 1 — parse developer ID
        Long developerIdToRemove;
        try {
            developerIdToRemove = Long.parseLong(developerIdInput);
        } catch (NumberFormatException e) {
            teamView.onMemberRemoveFailed("Invalid ID. Please enter a number.");
            return;
        }

        // Step 2 — get this user's developer profile
        Developer myDeveloper = BuildTogetherDB.getInstance()
                .getDeveloperByUserId(user.getId());
        if (myDeveloper == null) {
            teamView.onMemberRemoveFailed(
                    "Please complete your developer profile first");
            return;
        }

        // Step 3 — cannot remove yourself (team leader)
        if (developerIdToRemove.equals(myDeveloper.getId())) {
            teamView.onMemberRemoveFailed(
                    "You cannot remove yourself. You are the team leader.");
            return;
        }

        // Step 4 — get this user's team
        Team myTeam = BuildTogetherDB.getInstance()
                .getTeamByLeaderId(myDeveloper.getId());
        if (myTeam == null) {
            teamView.onMemberRemoveFailed("You don't have a team yet.");
            return;
        }

        // Step 5 — remove the member
        boolean removed = BuildTogetherDB.getInstance()
                .removeTeamMember(myTeam.getId(), developerIdToRemove);
        if (removed) {
            teamView.onMemberRemoved();
        } else {
            teamView.onMemberRemoveFailed(
                    "This developer is not in your team.");
        }
    }
}