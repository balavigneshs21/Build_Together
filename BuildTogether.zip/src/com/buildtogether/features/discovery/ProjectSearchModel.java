package com.buildtogether.features.discovery;

import com.buildtogether.dto.Developer;
import com.buildtogether.dto.Investor;
import com.buildtogether.dto.Project;
import com.buildtogether.dto.Team;
import com.buildtogether.dto.TeamMember;
import com.buildtogether.dto.TechStack;
import com.buildtogether.repository.BuildTogetherDB;

import java.util.List;
import java.util.Locale;

class ProjectSearchModel {

    private final ProjectSearchView projectSearchView;

    ProjectSearchModel(ProjectSearchView projectSearchView) {
        this.projectSearchView = projectSearchView;
    }

    // =========================================================================
    // Load all investors
    // =========================================================================

    void loadAllInvestors() {
        List<Investor> investors = BuildTogetherDB.getInstance().getAllInvestors();
        if (investors.isEmpty()) {
            projectSearchView.showNoInvestorsFound();
            return;
        }
        projectSearchView.showAllInvestors(investors);
    }

    // =========================================================================
    // Search investors by company name
    // =========================================================================

    void searchInvestorsByCompany(String companyName) {
        if (companyName == null || companyName.isEmpty()) {
            projectSearchView.showError("Company name cannot be empty");
            return;
        }

        List<Investor> all = BuildTogetherDB.getInstance().getAllInvestors();
        List<Investor> result = new java.util.ArrayList<>();

        String key = companyName.trim().toLowerCase(Locale.ROOT);
        for (Investor investor : all) {
            if (investor.getCompanyName() != null
                    && investor.getCompanyName()
                        .toLowerCase(Locale.ROOT).contains(key)) {
                result.add(investor);
            }
        }

        if (result.isEmpty()) {
            projectSearchView.showNoInvestorsFound();
        } else {
            projectSearchView.showAllInvestors(result);
        }
    }

    // =========================================================================
    // Load all projects
    // =========================================================================

    void loadAllProjects() {
        List<Project> projects = BuildTogetherDB.getInstance().getAllProjects();
        if (projects.isEmpty()) {
            projectSearchView.showNoProjectsFound();
            return;
        }
        projectSearchView.showAllProjects(projects);
    }

    // =========================================================================
    // Filter by domain
    // =========================================================================

    void filterByDomain(String domain) {
        if (domain == null || domain.isEmpty()) {
            projectSearchView.showError("Domain cannot be empty");
            return;
        }

        List<Project> result = BuildTogetherDB.getInstance()
                .getProjectsByDomain(domain);

        if (result.isEmpty()) {
            projectSearchView.showNoProjectsFound();
        } else {
            projectSearchView.showAllProjects(result);
        }
    }

    // =========================================================================
    // Filter by budget
    // =========================================================================

    void filterByBudget(String budgetInput) {
        Double maxBudget;
        try {
            maxBudget = Double.parseDouble(budgetInput);
            if (maxBudget <= 0) {
                projectSearchView.showError("Budget must be greater than 0");
                return;
            }
        } catch (NumberFormatException e) {
            projectSearchView.showError("Invalid budget. Please enter a number.");
            return;
        }

        List<Project> result = BuildTogetherDB.getInstance()
                .getProjectsByMaxBudget(maxBudget);

        if (result.isEmpty()) {
            projectSearchView.showNoProjectsFound();
        } else {
            projectSearchView.showAllProjects(result);
        }
    }

    // =========================================================================
    // Filter by technology
    // =========================================================================

    void filterByTechnology(String technology) {
        if (technology == null || technology.isEmpty()) {
            projectSearchView.showError("Technology name cannot be empty");
            return;
        }

        List<Project> result = BuildTogetherDB.getInstance()
                .getProjectsByTechnology(technology);

        if (result.isEmpty()) {
            projectSearchView.showNoProjectsFound();
        } else {
            projectSearchView.showAllProjects(result);
        }
    }

    // =========================================================================
    // Load team details for a project
    // =========================================================================

    void loadTeamDetails(String projectIdInput) {

        // Step 1 — parse project ID
        Long projectId;
        try {
            projectId = Long.parseLong(projectIdInput);
        } catch (NumberFormatException e) {
            projectSearchView.showError("Invalid project ID. Please enter a number.");
            return;
        }

        // Step 2 — get the project
        Project project = BuildTogetherDB.getInstance().getProjectById(projectId);
        if (project == null) {
            projectSearchView.showError("No project found with ID: " + projectId);
            return;
        }

        // Step 3 — get the team
        Team team = BuildTogetherDB.getInstance().getTeamById(project.getTeamId());
        if (team == null) {
            projectSearchView.showTeamNotFound();
            return;
        }

        // Step 4 — get team members
        List<TeamMember> members = BuildTogetherDB.getInstance()
                .getMembersOfTeam(team.getId());

        // Step 5 — get tech stacks for this project
        List<TechStack> techStacks = BuildTogetherDB.getInstance()
                .getTechStackByProjectId(projectId);

        // Step 6 — get all developers (to show their skills)
        List<Developer> developers = BuildTogetherDB.getInstance().getAllDevelopers();

        projectSearchView.showTeamDetails(team, members, techStacks, developers);
    }
}