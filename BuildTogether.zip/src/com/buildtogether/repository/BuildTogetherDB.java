package com.buildtogether.repository;

import com.buildtogether.dto.ContactRequest;
import com.buildtogether.dto.Developer;
import com.buildtogether.dto.FundingApplication;
import com.buildtogether.dto.Investment;
import com.buildtogether.dto.Investor;
import com.buildtogether.dto.Project;
import com.buildtogether.dto.Team;
import com.buildtogether.dto.TeamMember;
import com.buildtogether.dto.TechStack;
import com.buildtogether.dto.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BuildTogetherDB {

    private BuildTogetherDB() {
    }

    private static BuildTogetherDB instance = null;

    public static BuildTogetherDB getInstance() {
        if (instance == null) {
            instance = new BuildTogetherDB();
        }
        return instance;
    }

    // ─── Lists (your in-memory tables) ───────────────────────────────────────

    private final List<User>               users               = new ArrayList<>();
    private final List<Developer>          developers          = new ArrayList<>();
    private final List<Investor>           investors           = new ArrayList<>();
    private final List<Team>               teams               = new ArrayList<>();
    private final List<TeamMember>         teamMembers         = new ArrayList<>();
    private final List<Project>            projects            = new ArrayList<>();
    private final List<TechStack>          techStacks          = new ArrayList<>();
    private final List<FundingApplication> fundingApplications = new ArrayList<>();
    private final List<Investment>         investments         = new ArrayList<>();
    private final List<ContactRequest>     contactRequests     = new ArrayList<>();

    // ─── Primary key counters (auto-increment IDs) ───────────────────────────

    private long userPk               = 0L;
    private long developerPk          = 0L;
    private long investorPk           = 0L;
    private long teamPk               = 0L;
    private long teamMemberPk         = 0L;
    private long projectPk            = 0L;
    private long techStackPk          = 0L;
    private long fundingApplicationPk = 0L;
    private long investmentPk         = 0L;
    private long contactRequestPk     = 0L;

    // =========================================================================
    // USER METHODS
    // =========================================================================

    public User addUser(User user) {
        if (user == null) return null;
        if (user.getEmail() == null || user.getEmail().trim().isEmpty()) return null;
        userPk++;
        user.setId(userPk);
        if (user.getCreatedAt() == null) {
            user.setCreatedAt(System.currentTimeMillis());
        }
        if (user.getStatus() == null) {
            user.setStatus(User.UserStatus.ACTIVE);
        }
        users.add(user);
        return user;
    }

    public User getUserByEmail(String email) {
        if (email == null) return null;
        String key = email.trim().toLowerCase(Locale.ROOT);
        if (key.isEmpty()) return null;
        for (User user : users) {
            if (user.getEmail() != null
                    && user.getEmail().trim().toLowerCase(Locale.ROOT).equals(key)) {
                return user;
            }
        }
        return null;
    }

    public User getUserById(Long id) {
        if (id == null) return null;
        for (User user : users) {
            if (id.equals(user.getId())) return user;
        }
        return null;
    }

    public User authenticateUser(String email, String password) {
        User user = getUserByEmail(email);
        if (user == null) return null;
        if (password == null || !password.equals(user.getPassword())) return null;
        return user;
    }

    public boolean isEmailTaken(String email) {
        return getUserByEmail(email) != null;
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    // =========================================================================
    // DEVELOPER METHODS
    // =========================================================================

    public Developer addDeveloper(Developer developer) {
        if (developer == null) return null;
        developerPk++;
        developer.setId(developerPk);
        developers.add(developer);
        return developer;
    }

    public Developer getDeveloperByUserId(Long userId) {
        if (userId == null) return null;
        for (Developer developer : developers) {
            if (userId.equals(developer.getUserId())) return developer;
        }
        return null;
    }

    public Developer getDeveloperById(Long id) {
        if (id == null) return null;
        for (Developer developer : developers) {
            if (id.equals(developer.getId())) return developer;
        }
        return null;
    }

    public List<Developer> getAllDevelopers() {
        return new ArrayList<>(developers);
    }

    // =========================================================================
    // INVESTOR METHODS
    // =========================================================================

    public Investor addInvestor(Investor investor) {
        if (investor == null) return null;
        investorPk++;
        investor.setId(investorPk);
        investors.add(investor);
        return investor;
    }

    public Investor getInvestorByUserId(Long userId) {
        if (userId == null) return null;
        for (Investor investor : investors) {
            if (userId.equals(investor.getUserId())) return investor;
        }
        return null;
    }

    public Investor getInvestorById(Long id) {
        if (id == null) return null;
        for (Investor investor : investors) {
            if (id.equals(investor.getId())) return investor;
        }
        return null;
    }

    public List<Investor> getAllInvestors() {
        return new ArrayList<>(investors);
    }

    // =========================================================================
    // TEAM METHODS
    // =========================================================================

    public Team addTeam(Team team) {
        if (team == null) return null;
        teamPk++;
        team.setId(teamPk);
        if (team.getCreatedAt() == null) {
            team.setCreatedAt(System.currentTimeMillis());
        }
        teams.add(team);
        return team;
    }

    public Team getTeamById(Long id) {
        if (id == null) return null;
        for (Team team : teams) {
            if (id.equals(team.getId())) return team;
        }
        return null;
    }

    public Team getTeamByLeaderId(Long leaderId) {
        if (leaderId == null) return null;
        for (Team team : teams) {
            if (leaderId.equals(team.getTeamLeaderId())) return team;
        }
        return null;
    }

    public List<Team> getAllTeams() {
        return new ArrayList<>(teams);
    }

    // =========================================================================
    // TEAM MEMBER METHODS
    // =========================================================================

    public TeamMember addTeamMember(TeamMember teamMember) {
        if (teamMember == null) return null;
        teamMemberPk++;
        teamMember.setId(teamMemberPk);
        teamMembers.add(teamMember);
        return teamMember;
    }

    public List<TeamMember> getMembersOfTeam(Long teamId) {
        List<TeamMember> result = new ArrayList<>();
        if (teamId == null) return result;
        for (TeamMember member : teamMembers) {
            if (teamId.equals(member.getTeamId())) result.add(member);
        }
        return result;
    }

    public boolean isAlreadyInTeam(Long teamId, Long developerId) {
        if (teamId == null || developerId == null) return false;
        for (TeamMember member : teamMembers) {
            if (teamId.equals(member.getTeamId())
                    && developerId.equals(member.getDeveloperId())) {
                return true;
            }
        }
        return false;
    }

    public boolean removeTeamMember(Long teamId, Long developerId) {
        if (teamId == null || developerId == null) return false;
        return teamMembers.removeIf(member ->
                teamId.equals(member.getTeamId())
                && developerId.equals(member.getDeveloperId()));
    }

    public int getTeamMemberCount(Long teamId) {
        return getMembersOfTeam(teamId).size();
    }

    // =========================================================================
    // PROJECT METHODS
    // =========================================================================

    public Project addProject(Project project) {
        if (project == null) return null;
        projectPk++;
        project.setId(projectPk);
        if (project.getCreatedAt() == null) {
            project.setCreatedAt(System.currentTimeMillis());
        }
        if (project.getStatus() == null) {
            project.setStatus(Project.ProjectStatus.IDEA);
        }
        projects.add(project);
        return project;
    }

    public Project getProjectById(Long id) {
        if (id == null) return null;
        for (Project project : projects) {
            if (id.equals(project.getId())) return project;
        }
        return null;
    }

    public Project updateProject(Project project) {
        if (project == null || project.getId() == null) return null;
        for (int i = 0; i < projects.size(); i++) {
            if (project.getId().equals(projects.get(i).getId())) {
                projects.set(i, project);
                return project;
            }
        }
        return null;
    }

    public List<Project> getProjectsByTeamId(Long teamId) {
        List<Project> result = new ArrayList<>();
        if (teamId == null) return result;
        for (Project project : projects) {
            if (teamId.equals(project.getTeamId())) result.add(project);
        }
        return result;
    }

    public List<Project> getAllProjects() {
        return new ArrayList<>(projects);
    }

    public List<Project> getProjectsByDomain(String domain) {
        List<Project> result = new ArrayList<>();
        if (domain == null || domain.trim().isEmpty()) return result;
        String key = domain.trim().toLowerCase(Locale.ROOT);
        for (Project project : projects) {
            if (project.getDomain() != null
                    && project.getDomain().trim().toLowerCase(Locale.ROOT).contains(key)) {
                result.add(project);
            }
        }
        return result;
    }

    public List<Project> getProjectsByMaxBudget(Double maxBudget) {
        List<Project> result = new ArrayList<>();
        if (maxBudget == null) return result;
        for (Project project : projects) {
            if (project.getEstimatedCost() != null
                    && project.getEstimatedCost() <= maxBudget) {
                result.add(project);
            }
        }
        return result;
    }

    // =========================================================================
    // TECH STACK METHODS
    // =========================================================================

    public TechStack addTechStack(TechStack techStack) {
        if (techStack == null) return null;
        techStackPk++;
        techStack.setId(techStackPk);
        techStacks.add(techStack);
        return techStack;
    }

    public List<TechStack> getTechStackByProjectId(Long projectId) {
        List<TechStack> result = new ArrayList<>();
        if (projectId == null) return result;
        for (TechStack tech : techStacks) {
            if (projectId.equals(tech.getProjectId())) result.add(tech);
        }
        return result;
    }

    public List<Project> getProjectsByTechnology(String technology) {
        List<Project> result = new ArrayList<>();
        if (technology == null || technology.trim().isEmpty()) return result;
        String key = technology.trim().toLowerCase(Locale.ROOT);
        for (TechStack tech : techStacks) {
            if (tech.getTechnology() != null
                    && tech.getTechnology().trim().toLowerCase(Locale.ROOT).contains(key)) {
                Project project = getProjectById(tech.getProjectId());
                if (project != null && !result.contains(project)) {
                    result.add(project);
                }
            }
        }
        return result;
    }

    // =========================================================================
    // FUNDING APPLICATION METHODS
    // =========================================================================

    public FundingApplication addFundingApplication(FundingApplication application) {
        if (application == null) return null;
        fundingApplicationPk++;
        application.setId(fundingApplicationPk);
        if (application.getAppliedAt() == null) {
            application.setAppliedAt(System.currentTimeMillis());
        }
        if (application.getStatus() == null) {
            application.setStatus(FundingApplication.ApplicationStatus.PENDING);
        }
        fundingApplications.add(application);
        return application;
    }

    public FundingApplication updateFundingApplication(FundingApplication application) {
        if (application == null || application.getId() == null) return null;
        for (int i = 0; i < fundingApplications.size(); i++) {
            if (application.getId().equals(fundingApplications.get(i).getId())) {
                fundingApplications.set(i, application);
                return application;
            }
        }
        return null;
    }

    public List<FundingApplication> getFundingApplicationsByProjectId(Long projectId) {
        List<FundingApplication> result = new ArrayList<>();
        if (projectId == null) return result;
        for (FundingApplication app : fundingApplications) {
            if (projectId.equals(app.getProjectId())) result.add(app);
        }
        return result;
    }

    public List<FundingApplication> getFundingApplicationsByInvestorId(Long investorId) {
        List<FundingApplication> result = new ArrayList<>();
        if (investorId == null) return result;
        for (FundingApplication app : fundingApplications) {
            if (investorId.equals(app.getInvestorId())) result.add(app);
        }
        return result;
    }

    public boolean hasPendingApplication(Long projectId, Long investorId) {
        if (projectId == null || investorId == null) return false;
        for (FundingApplication app : fundingApplications) {
            if (projectId.equals(app.getProjectId())
                    && investorId.equals(app.getInvestorId())
                    && app.getStatus() == FundingApplication.ApplicationStatus.PENDING) {
                return true;
            }
        }
        return false;
    }

    // =========================================================================
    // INVESTMENT METHODS
    // =========================================================================

    public Investment addInvestment(Investment investment) {
        if (investment == null) return null;
        investmentPk++;
        investment.setId(investmentPk);
        if (investment.getInvestedAt() == null) {
            investment.setInvestedAt(System.currentTimeMillis());
        }
        investments.add(investment);
        return investment;
    }

    public List<Investment> getInvestmentsByInvestorId(Long investorId) {
        List<Investment> result = new ArrayList<>();
        if (investorId == null) return result;
        for (Investment investment : investments) {
            if (investorId.equals(investment.getInvestorId())) result.add(investment);
        }
        return result;
    }

    public List<Investment> getInvestmentsByProjectId(Long projectId) {
        List<Investment> result = new ArrayList<>();
        if (projectId == null) return result;
        for (Investment investment : investments) {
            if (projectId.equals(investment.getProjectId())) result.add(investment);
        }
        return result;
    }

    // =========================================================================
    // CONTACT REQUEST METHODS
    // =========================================================================

    public ContactRequest addContactRequest(ContactRequest contactRequest) {
        if (contactRequest == null) return null;
        contactRequestPk++;
        contactRequest.setId(contactRequestPk);
        if (contactRequest.getSentAt() == null) {
            contactRequest.setSentAt(System.currentTimeMillis());
        }
        if (contactRequest.getStatus() == null) {
            contactRequest.setStatus(ContactRequest.ContactStatus.PENDING);
        }
        contactRequests.add(contactRequest);
        return contactRequest;
    }

    public ContactRequest updateContactRequest(ContactRequest contactRequest) {
        if (contactRequest == null || contactRequest.getId() == null) return null;
        for (int i = 0; i < contactRequests.size(); i++) {
            if (contactRequest.getId().equals(contactRequests.get(i).getId())) {
                contactRequests.set(i, contactRequest);
                return contactRequest;
            }
        }
        return null;
    }

    public List<ContactRequest> getContactRequestsByTeamLeaderId(Long teamLeaderId) {
        List<ContactRequest> result = new ArrayList<>();
        if (teamLeaderId == null) return result;
        for (ContactRequest request : contactRequests) {
            if (teamLeaderId.equals(request.getTeamLeaderId())) result.add(request);
        }
        return result;
    }

    public List<ContactRequest> getContactRequestsByInvestorId(Long investorId) {
        List<ContactRequest> result = new ArrayList<>();
        if (investorId == null) return result;
        for (ContactRequest request : contactRequests) {
            if (investorId.equals(request.getInvestorId())) result.add(request);
        }
        return result;
    }

    public boolean hasAlreadyContacted(Long investorId, Long teamLeaderId) {
        if (investorId == null || teamLeaderId == null) return false;
        for (ContactRequest request : contactRequests) {
            if (investorId.equals(request.getInvestorId())
                    && teamLeaderId.equals(request.getTeamLeaderId())
                    && request.getStatus() == ContactRequest.ContactStatus.PENDING) {
                return true;
            }
        }
        return false;
    }
}
